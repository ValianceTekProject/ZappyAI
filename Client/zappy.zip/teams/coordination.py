##
## EPITECH PROJECT, 2025
## Zappy
## File description:
## coordination
##

import time
from typing import Dict, List, Any, Optional, Tuple
from protocol.commands import CommandManager, CommandStatus
from utils.logger import logger
from utils.game_state import GameState
from protocol.parser import Parser
from teams.message import Message, MessageType
from config import CommandType
import uuid

class TeamMember:
    def __init__(self, member_id: str):
        self.id = member_id
        self.level = 1
        self.position = (0, 0)
        self.inventory = {}
        self.last_seen = time.time()
        self.status = "active"  # active, busy, dead
        
    def update_from_status(self, data: Dict[str, Any]):
        """Met à jour les infos d'un membre depuis un message status."""
        self.level = data.get("level", self.level)
        self.position = data.get("position", self.position)
        self.inventory = data.get("inventory", self.inventory)
        self.last_seen = time.time()

class CoordinationManager:
    def __init__(self, command_manager: CommandManager, game_state: GameState):
        self.cmd_mgr = command_manager
        self.game_state = game_state
        self.player_id = str(uuid.uuid4())[:8]  # ID unique court
        
        # Gestion de l'équipe
        self.team_members: Dict[str, TeamMember] = {}
        self.pending_incantations: Dict[str, Dict] = {}  # sender_id -> incant_data
        self.resource_offers: List[Dict] = []
        self.help_requests: List[Dict] = []
        
        # Timers
        self.last_status_broadcast = 0
        self.last_cleanup = 0
        
        # Configuration
        self.status_broadcast_interval = 10.0  # Broadcast status toutes les 10s
        self.cleanup_interval = 30.0  # Nettoyage toutes les 30s
        self.member_timeout = 60.0  # Considère un membre mort après 60s sans nouvelles

    def process_broadcast_message(self, direction: int, raw_message: str):
        """Traite un message broadcast reçu."""
        logger.debug(f"[Broadcast <] raw='message {direction}, {raw_message}'")
        decoded = Message.decode_msg(raw_message)
        if not decoded:
            logger.debug("[Broadcast <] non-JSON ou non-Base64, ignoré")
            return

        msg_type, sender_id, data = decoded
        sender_lvl = data.get("level") or data.get("sender_level")
        logger.debug(f"[Coordo recv] from={sender_id} type={msg_type.value} "
                    f"level={sender_lvl} direction={direction} payload={data}")

        # Ignorer les agents d'un autre niveau
        if sender_lvl != self.game_state.level:
            logger.debug(f"[Coordo] Ignoré: niveau {sender_lvl} ≠ mon niveau {self.game_state.level}")
            return

        # Traite selon le type de message
        if msg_type == MessageType.STATUS:
            self._handle_status_message(sender_id, data)
        elif msg_type == MessageType.INCANTATION_REQUEST:
            logger.info(f"[Coordo] Reçu INC_REQ de {sender_id}, priority={data.get('priority')}")
            self._handle_incantation_request(sender_id, data, direction)
        elif msg_type == MessageType.INCANTATION_RESPONSE:
            logger.info(f"[Coordo] Reçu INC_RESP de {sender_id}, status={data['status']}")
            self._handle_incantation_response(sender_id, data)
        elif msg_type == MessageType.RESOURCE_SHARE:
            self._handle_resource_share(sender_id, data, direction)
        elif msg_type == MessageType.HELP_REQUEST:
            self._handle_help_request(sender_id, data, direction)
        elif msg_type == MessageType.DEATH_NOTICE:
            self._handle_death_notice(sender_id, data)
        elif msg_type == MessageType.POSITION_UPDATE:
            self._handle_position_update(sender_id, data)

    def _handle_status_message(self, sender_id: str, data: Dict[str, Any]):
        """Traite un message de statut d'un coéquipier."""
        if sender_id not in self.team_members:
            self.team_members[sender_id] = TeamMember(sender_id)
            logger.info(f"Nouveau coéquipier détecté: {sender_id}")
        
        self.team_members[sender_id].update_from_status(data)

    def _handle_incantation_request(self, sender_id: str, data: Dict[str, Any], direction: int):
        """Traite une demande d'incantation."""
        try:
            required_level = data.get("level", 1)
            required_players = data.get("required_players", 1)
            sender_pos = data.get("position", (0, 0))
            
            # Vérifie si on peut aider
            can_help = (
                self.game_state.level == required_level and
                self.game_state.get_food_count() > 50 and  # Assez de nourriture pour se déplacer
                not self._is_busy_with_incantation()
            )
            
            if can_help:
                # Estime le temps pour arriver
                distance = self._estimate_distance_to_direction(direction)
                eta = distance * 7  # 7 unités de temps par case
                
                # Envoie une réponse positive
                response_msg = Message.create_incantation_response(
                    self.player_id, sender_id, "coming", eta
                )
                self._broadcast_message(response_msg)
                
                # Stocke la demande pour traitement
                self.pending_incantations[sender_id] = {
                    "position": sender_pos,
                    "level": required_level,
                    "direction": direction,
                    "eta": eta,
                    "timestamp": time.time()
                }
                
                logger.info(f"Accepté incantation de {sender_id}, ETA: {eta}s")
            else:
                # Envoie une réponse négative
                reason = "busy" if self._is_busy_with_incantation() else "can't"
                response_msg = Message.create_incantation_response(
                    self.player_id, sender_id, reason
                )
                self._broadcast_message(response_msg)
                
        except Exception as e:
            logger.error(f"Erreur lors du traitement de la demande d'incantation: {e}")

    def _handle_incantation_response(self, sender_id: str, data: Dict[str, Any]):
        """Traite une réponse à notre demande d'incantation."""
        response = data.get("response", "")
        eta = data.get("eta", 0)
        
        if response == "coming":
            logger.info(f"{sender_id} arrive pour l'incantation (ETA: {eta}s)")
        elif response == "busy":
            logger.info(f"{sender_id} est occupé et ne peut pas aider")
        elif response == "can't":
            logger.info(f"{sender_id} ne peut pas aider avec l'incantation")

    def _handle_resource_share(self, sender_id: str, data: Dict[str, Any], direction: int):
        """Traite un message de partage de ressource."""
        resource = data.get("resource", "")
        quantity = data.get("quantity", 0)
        position = data.get("position", (0, 0))
        action = data.get("action", "drop")
        
        if action == "drop" and self._need_resource(resource):
            self.resource_offers.append({
                "sender": sender_id,
                "resource": resource,
                "quantity": quantity,
                "position": position,
                "direction": direction,
                "timestamp": time.time()
            })
            logger.info(f"Ressource {resource} disponible via {sender_id}")

    def _handle_help_request(self, sender_id: str, data: Dict[str, Any], direction: int):
        """Traite une demande d'aide."""
        help_type = data.get("help_type", "")
        position = data.get("position", (0, 0))
        urgency = data.get("urgency", 1)
        
        # Stocke la demande pour évaluation
        self.help_requests.append({
            "sender": sender_id,
            "help_type": help_type,
            "position": position,
            "urgency": urgency,
            "direction": direction,
            "timestamp": time.time()
        })
        
        logger.info(f"Demande d'aide de {sender_id}: {help_type} (urgence: {urgency})")

    def _handle_death_notice(self, sender_id: str, data: Dict[str, Any]):
        """Traite un avis de décès."""
        if sender_id in self.team_members:
            self.team_members[sender_id].status = "dead"
            logger.info(f"Coéquipier {sender_id} est mort: {data.get('cause', 'unknown')}")

    def _handle_position_update(self, sender_id: str, data: Dict[str, Any]):
        """Traite une mise à jour de position."""
        if sender_id in self.team_members:
            old_pos = data.get("old_position", (0, 0))
            new_pos = data.get("new_position", (0, 0))
            self.team_members[sender_id].position = new_pos

    def should_broadcast_status(self) -> bool:
        """Détermine s'il faut envoyer un message de statut."""
        return time.time() - self.last_status_broadcast > self.status_broadcast_interval

    def create_status_broadcast(self) -> str:
        """Crée un message de statut à broadcaster."""
        self.last_status_broadcast = time.time()
        return Message.create_status_message(
            self.player_id,
            self.game_state.level,
            self.game_state.position,
            self.game_state.inventory
        )

    def request_incantation_help(self) -> str:
        """Crée une demande d'aide pour incantation."""
        required_players = self.game_state.get_required_player_count()
        return Message.create_incantation_request(
            self.player_id,
            self.game_state.level,
            self.game_state.position,
            required_players
        )

    def get_best_help_request(self) -> Optional[Dict]:
        """Retourne la meilleure demande d'aide à traiter."""
        if not self.help_requests:
            return None
        
        # Trie par urgence et proximité
        valid_requests = [
            req for req in self.help_requests
            if time.time() - req["timestamp"] < 120  # Requests valides 2 minutes
        ]
        
        if not valid_requests:
            return None
        
        # Priorité: urgence élevée et help_type = "food"
        food_requests = [req for req in valid_requests if req["help_type"] == "food"]
        if food_requests:
            return max(food_requests, key=lambda x: x["urgency"])
        
        return max(valid_requests, key=lambda x: x["urgency"])

    def cleanup_old_data(self):
        """Nettoie les données anciennes."""
        if time.time() - self.last_cleanup < self.cleanup_interval:
            return
        
        self.last_cleanup = time.time()
        current_time = time.time()
        
        # Nettoie les membres inactifs
        inactive_members = [
            member_id for member_id, member in self.team_members.items()
            if current_time - member.last_seen > self.member_timeout
        ]
        
        for member_id in inactive_members:
            del self.team_members[member_id]
            logger.info(f"Membre inactif supprimé: {member_id}")
        
        # Nettoie les demandes anciennes
        self.pending_incantations = {
            k: v for k, v in self.pending_incantations.items()
            if current_time - v["timestamp"] < 300  # 5 minutes
        }
        
        self.resource_offers = [
            offer for offer in self.resource_offers
            if current_time - offer["timestamp"] < 120  # 2 minutes
        ]
        
        self.help_requests = [
            req for req in self.help_requests
            if current_time - req["timestamp"] < 120  # 2 minutes
        ]

    def _broadcast_message(self, message: str):
        """Envoie un message via broadcast."""
        if message:
            broadcast_cmd = f"Broadcast {message}"
            self.cmd_mgr.broadcast(message)

    def _is_busy_with_incantation(self) -> bool:
        """Vérifie si on est occupé avec une incantation."""
        # Logique à adapter selon votre système
        return len(self.pending_incantations) > 0

    def _need_resource(self, resource: str) -> bool:
        """Vérifie si on a besoin d'une ressource."""
        current_qty = self.game_state.inventory.get(resource, 0)
        requirements = self.game_state.get_incantation_requirements()
        needed_qty = requirements.get(resource, 0)
        
        return current_qty < needed_qty

    def _estimate_distance_to_direction(self, direction: int) -> int:
        """Estime la distance basée sur la direction du broadcast."""
        # Approximation grossière basée sur la direction
        # Dans un vrai cas, vous devriez avoir une meilleure estimation
        direction_distances = {
            0: 1,  # Même tile
            1: 2,  # Devant
            2: 3,  # Diagonale avant-droite
            3: 2,  # Droite
            4: 3,  # Diagonale arrière-droite
            5: 4,  # Derrière
            6: 3,  # Diagonale arrière-gauche
            7: 2,  # Gauche
            8: 3   # Diagonale avant-gauche
        }
        return direction_distances.get(direction, 5)

    def get_team_status(self) -> Dict[str, Any]:
        """Retourne un résumé de l'état de l'équipe."""
        return {
            "team_size": len(self.team_members),
            "active_members": len([m for m in self.team_members.values() if m.status == "active"]),
            "pending_incantations": len(self.pending_incantations),
            "resource_offers": len(self.resource_offers),
            "help_requests": len(self.help_requests)
        }