##
## EPITECH PROJECT, 2025
## Zappy
## File description:
## message_manager
##

from typing import List, Tuple
from protocol.commands import Command, CommandManager
from utils.logger import logger
from protocol.parser import Parser
from teams.message import Message

class MessageManager:
    def __init__(self, command_manager: CommandManager, agent):
        self.cmd_mgr = command_manager
        self.agent = agent
        self.is_dead = False

    def process_message(self, raw_responses: List[str]) -> List[Command]:
        """
        Sépare les messages serveur :
         - réponses de commande (redirigées vers CommandManager)
         - événements asynchrones (stockés dans une liste séparée)
        """
        command_responses = []

        for response in raw_responses:
            response = response.strip()

            if Parser.is_dead_response(response):
                command_responses.append(response)
                self.is_dead = True
                continue

            parsed = Parser.parse_broadcast_response(response)
            if parsed:
                dir_, token = parsed["direction"], parsed["token"]
                logger.debug(f"[MessageMgr] reçu broadcast dir={dir_} token={token}")
                dec = Message.decode_msg(token)
                if dec:
                    msg_type, sender_lvl, payload = dec
                    logger.debug(f"[MessageMgr] broadcast décodé type={msg_type} level={sender_lvl} payload={payload}")
                    # appelle CoordinationManager
                    self.agent.planner.coordo.process_broadcast_message(msg_type, sender_lvl, payload, dir_)
                continue

            completed.append(response)

        completed = self.cmd_mgr.process_responses(command_responses)
        return completed
