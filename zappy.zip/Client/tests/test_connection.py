##
## EPITECH PROJECT, 2025
## Zappy
## File description:
## test_connection
##

import pytest
from protocol.connection import Connection

def test_handshake():
    # TODO: mock serveur
    assert True