##
## EPITECH PROJECT, 2025
## Zappy
## File description:
## coordination
##

import time
from typing import Dict, List, Any, Optional, Tuple
from protocol.commands import CommandManager, CommandStatus
from utils.logger import logger
from utils.game_state import GameState
from protocol.parser import Parser
from teams.message import Message, MessageType
from teams.message_checker import MessageBus
from config import CommandType

class TeamMember:
    def __init__(self, member_id: str):
        self.id = member_id
        self.level = 1
        self.position = (0, 0)
        self.inventory = {}
        self.last_seen = time.time()
        self.status = "active"  # active, busy, dead

    def update_from_status(self, data: Dict[str, Any]):
        """Met à jour les infos d'un membre depuis un message status."""
        self.level = data.get("level", self.level)
        self.position = data.get("position", self.position)
        self.inventory = data.get("inventory", self.inventory)
        self.last_seen = time.time()

from teams.message import Message, MessageType

class CoordinationManager:
    def __init__(self, bus: MessageBus, cmd_mgr, game_state):
        self.bus = bus
        self.cmd_mgr = cmd_mgr
        self.state = game_state
        self.helpers = set()

        # Souscription aux messages qui nous intéressent
        bus.subscribe(MessageType.INCANTATION_REQUEST,  self._on_inc_req)
        bus.subscribe(MessageType.INCANTATION_RESPONSE, self._on_inc_resp)
        bus.subscribe(MessageType.HELP_REQUEST,          self._on_help_req)

    def _on_inc_req(self, sender_id, data, direction):
        """Un coéquipier lance une incant → on répond coming/busy."""
        can = (
            self.state.level == data["level"] and
            self.state.get_food_count() > 50 and
            not self._am_busy()
        )
        response = "coming" if can else "busy"
        eta = None
        if can:
            eta = self._estimate_eta(direction)
        msg = Message.create_incantation_response(
            sender_id=self.state.team_id,
            request_sender=sender_id,
            response=response,
            eta=eta
        )
        self.cmd_mgr.broadcast(msg)

    def _on_inc_resp(self, sender_id, data, direction):
        if data["response"] == "coming":
            self.helpers.add(sender_id)

    def _on_help_req(self, sender_id, data, direction):
        # Par exemple, on stocke ou on réagit directement
        print(f"Help requested: {data}")

    def request_incant_help(self):
        msg = Message.create_incantation_request(
            sender_id=self.state.team_id,
            level=self.state.level,
            position=self.state.position,
            required_players=self.state.get_required_player_count()
        )
        self.cmd_mgr.broadcast(msg)

    def get_helpers(self):
        return list(self.helpers)

    def _am_busy(self):
        # vrai si déjà en train de préparer une incant, etc.
        return False

    def _estimate_eta(self, direction):
        # logique simplifiée
        return max(1, direction) * 7
